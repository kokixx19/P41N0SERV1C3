<?php

//DEFINE("DB_HOST", "190.116.0.181:3308");
//DEFINE("DB_NAME", "testpainodata");
//DEFINE("DB_USER", "devuser");
//DEFINE("DB_PASS", "D3s4rrollo");

//DEFINE("DB_HOST", "192.168.1.66:3308");
//DEFINE("DB_NAME", "testpaino");
//DEFINE("DB_USER", "paino");
//DEFINE("DB_PASS", "123456");

DEFINE("DB_HOST", "23.229.226.35:3306");
DEFINE("DB_NAME", "testpaino");
DEFINE("DB_USER", "kokixx19");
DEFINE("DB_PASS", "kokixx19");

date_default_timezone_set('America/Lima');
