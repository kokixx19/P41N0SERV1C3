<?php

header('Access-Control-Allow-Origin: *'); 
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');

header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
require_once dirname(__FILE__, 3) . "./app/db/DB.php";
require_once dirname(__FILE__, 3) . "./app/services/GeneralServices.php";

class VehiculoTran{
  public function __construct()
  {
    $this->db=new Conexion();  
  }

  public function insrt_Cliente2($PerTIde,$PerIdeNro,$PerTper,$PerApePat,$PerApeMat,$PerNom,$PerECiv,$PerNacion,$PerEmail,$PerRazSoc,$PerTlfNro){
    try{
       $sql='Call sp_insrt_vehiculo(?,?,?,?,?,?,?,?,?,?,?)';
       $param=array($PerTIde,$PerIdeNro,$PerTper,$PerApePat,$PerApeMat,$PerNom,$PerECiv,$PerNacion,$PerEmail,$PerRazSoc,$PerTlfNro);
       $data=$this->db->query($sql,$param);
       return $data;
      
    }catch(Exception $e){
        $this->Estado=-1;
        $this->Mensaje='Error en el proceso, consulte con el administrador.';
        $this->MensajeError=$e->getMessage();
    }
  }
  public function insrt_Cliente3($PerTIde,$PerIdeNro,$PerApePat,$PerApeMat,$PerNom,$PerEmail,$PerTlfNro){
    try{
       $sql='Call sp_insrt_comprador_repre(?,?,?,?,?,?,?)';
       $param=array($PerTIde,$PerIdeNro,$PerApePat,$PerApeMat,$PerNom,$PerEmail,$PerTlfNro);
       $data=$this->db->query($sql,$param);
       return $data;
      
    }catch(Exception $e){
        $this->Estado=-1;
        $this->Mensaje='Error en el proceso, consulte con el administrador.';
        $this->MensajeError=$e->getMessage();
    }
  }

  public function reporte_vh($placa){
    try{
       $sql='Call sp_reporte_vh(?)';
       $param=array($placa);
       $data=$this->db->query($sql,$param);
       return $data;
      
    }catch(Exception $e){
        $this->Estado=-1;
        $this->Mensaje='Error en el proceso, consulte con el administrador.';
        $this->MensajeError=$e->getMessage();
    }
  }

  public function insrt_soli($TipoPern,$PerTideV,$PerNroV,$Repre_V,$PerTideRV,$PerNroRV,$PerTideC,$PerNroC,$Repre_C,$PerTideRC,$PerNroRC,$Placa,$Moneda,$Monto){
    try{
       $sql='Call spu_insrt_vh_soli(?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
       $param=array($TipoPern,$PerTideV,$PerNroV,$Repre_V,$PerTideRV,$PerNroRV,$PerTideC,$PerNroC,$Repre_C,$PerTideRC,$PerNroRC,$Placa,$Moneda,$Monto);
       $data=$this->db->query($sql,$param);
       return $data;
      
    }catch(Exception $e){
        $this->Estado=-1;
        $this->Mensaje='Error en el proceso, consulte con el administrador.';
        $this->MensajeError=$e->getMessage();
    }
  }
}
?>