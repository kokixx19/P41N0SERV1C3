<?php

header('Access-Control-Allow-Origin: *'); 
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');

header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
require_once dirname(__FILE__, 3) . "./app/db/DB.php";
require_once dirname(__FILE__, 3) . "./app/services/GeneralServices.php";

class Cliente{
  public function __construct()
  {
    $this->db=new Conexion();  
  }


/*INSERT PODERES*/
  public function INSERT_PODERES(
        $_PO_T_DOC, 
        $_PO_N_DOC ,
        $_AP_T_DOC_APO ,
        $_AP_N_DOC_APO ,
        $_DEC_INFO ,
        $_DEC_CONS ,
        $_COD_PENSION ,
        $_TIP_PENSION ,
        $_OBS_REDACT,
        $_N_CUENTA ,
        $_CAT_PODER )

  {
    try{
       $sql='CALL SP_INSERT_S_PODERES(?,?,?,?,?,?,?,?,?,?,?)';
       $param=array(
        $_PO_T_DOC, 
        $_PO_N_DOC ,
        $_AP_T_DOC_APO ,
        $_AP_N_DOC_APO ,
        $_DEC_INFO ,
        $_DEC_CONS ,
        $_COD_PENSION ,
        $_TIP_PENSION,
        $_OBS_REDACT,
        $_N_CUENTA ,
        $_CAT_PODER);
       $data=$this->db->query($sql,$param);
       return $data;
      
    }catch(Exception $e){
        $this->Estado=-1;
        $this->Mensaje='Error en el proceso, consulte con el administrador.';
        $this->MensajeError=$e->getMessage();
    }
  }

/*FIN INSER PODERES*/
}
?>