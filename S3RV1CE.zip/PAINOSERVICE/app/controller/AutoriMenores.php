<?php
require_once dirname(__FILE__, 3) . "./app/libs/functions.php";
require_once dirname(__FILE__, 3) . "./app/model/AutoriMenores_Model.php";

//header("Content-Type: application/json; charset=UTF-8");
header('Access-Control-Allow-Origin: *');
session_start();
$_POST['op'] = isset($_POST['op']) ? $_POST['op'] : die();




switch ($_POST['op']) {

    case 'get_personaXnumdoc':

        $cm = new AutoriMenores_Model;
        $dataDB = $cm->get_personaXnumdoc($_POST['PerTide'],$_POST['PerIdeNro']);
        echo json_encode($dataDB);
        break;

    case 'get_DomicilioXnumdoc':

        $cm = new AutoriMenores_Model;
        $dataDB = $cm->get_DomicilioXnumdoc($_POST['PerTide'],$_POST['PerIdeNro']);
        echo json_encode($dataDB);
        break;

    case 'get_HijosxPadre';
       $cm=new AutoriMenores_Model;
       $dataDB=$cm->get_HijosxPadre($_POST['PerIdeNroP'],$_POST['PerTIdeP']);
       echo json_encode($dataDB);
    break;

    case 'get_HijosxMadre';
    
       $cm=new AutoriMenores_Model;
       $dataDB=$cm->get_HijosxMadre($_POST['PerIdeNroM'],$_POST['PerTideM']);
       echo json_encode($dataDB);
    break;

    case 'sp_sel_Hijos';
    
       $cm=new AutoriMenores_Model;
       $dataDB=$cm->sp_sel_Hijos($_POST['PerIdeNro'],$_POST['PerTIde']);
       echo json_encode($dataDB);
    break;

    case 'get_HijosxPadreyMadre';
       $cm=new AutoriMenores_Model;
        $dataDB=$cm->get_HijosxPadreyMadre($_POST['PerIdeNroP'],$_POST['PerTideP'],$_POST['PerIdeNroM'],$_POST['PerTideM']);
        echo json_encode($dataDB);
    break;

    case 'sel_DomicilioUpdt';
       $cm=new AutoriMenores_Model;
        $dataDB=$cm->sel_DomicilioUpdt($_POST['PerDirCod'],$_POST['PerTide'],$_POST['PerIdeNro']);
        echo json_encode($dataDB);
    break;
   

    default:
        # code...
        break;
}
