<?php 
require_once dirname(__FILE__, 3) . "./app/libs/functions.php";
require_once dirname(__FILE__, 3) . "./app/model/ModelTransfVehicular.php";
header('Access-Control-Allow-Origin: *');

$_POST['op'] = isset($_POST['op']) ? $_POST['op'] : die();

switch($_POST['op'])
{
    case 'insrt_usu';
        $acc = new Usuario;
        $db = $acc->insrt_usuario($_POST['PerIdeNro']);
    break;

    if($db != "")
    {
        session_start();
        $_SESSION['login'] = true;
    }
    else
    {
        $_SESSION['login'] = false;
    }

    echo $_SESSION['login'];
}


?>