<?php
require_once dirname(__FILE__, 3) . "./app/db/DB.php";
require_once dirname(__FILE__, 3) . "./app/services/GeneralServices.php";

class Cliente{
  public function __construct()
  {
    $this->db=new Conexion();  
  }
  // llamar autenticacion usuario
   public function get_User($user_tmp,$pass_tmp){
    try{
       $sql='Call sp_get_User(?,?)';
       $param=array($user_tmp,$user_tmp);
       $data=$this->db->query($sql,$param);
       return $data;
      
    }catch(Exception $e){
        $this->Estado=-1;
        $this->Mensaje='Error en el proceso, consulte con el administrador.';
        $this->MensajeError=$e->getMessage();
    }
  }
  

  public function insrt_ClienteALL(
    $PerTide,
    $PerIdeNro,
    $PerTPer,
    $PerApePat,
    $PerApeMat,
    $PerNom,
    $PerNomCo,
    $PerECiv,
    $PerNacion,
    $PerTlfNro,
    $PerEmail,
    $PerObser,
    $PerAnuFch,
    $PerConyTIde,
    $PerConyIde,
    $OcuCod,
    $PerDirDes,
    $PerTIdeP,
    $PerIdeNroP,
    $PerTIdeM,
    $PerIdeNroM,
    $PerFchNac,
    $PerRazSoc,
    $PerRazSocEmail){
    try{
       $sql='Call sp_insrt_ClienteALL(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
       $param=array(
          $PerTide,
          $PerIdeNro,
          $PerTPer,
          $PerApePat,
          $PerApeMat,
          $PerNom,
          $PerNomCo,
          $PerECiv,
          $PerNacion,
          $PerTlfNro,
          $PerEmail,
          $PerObser,
          $PerAnuFch,
          $PerConyTIde,
          $PerConyIde,
          $OcuCod,
          $PerDirDes,
          $PerTIdeP,
          $PerIdeNroP,
          $PerTIdeM,
          $PerIdeNroM,
          $PerFchNac,
          $PerRazSoc,
          $PerRazSocEmail);
       $data=$this->db->query($sql,$param);
       return $data;
      
    }catch(Exception $e){
        $this->Estado=-1;
        $this->Mensaje='Error en el proceso, consulte con el administrador.';
        $this->MensajeError=$e->getMessage();
    }
  }

  public  function updt_Cliente($PerApePat,$PerApeMat,$PerNom,$PerECiv,$PerNacion,$PerEmail,$PerTlfNro,$PerTIde,$PerIdeNro){
    try{
       $sql='Call sp_updt_Cliente(?,?,?,?,?,?,?,?,?)';
       $param=array($PerApePat,$PerApeMat,$PerNom,$PerECiv,$PerNacion,$PerEmail,$PerTlfNro,$PerTIde,$PerIdeNro);
       $data=$this->db->query($sql,$param);
       return $data;
    }catch(Exception $e){
     $this->Estado=-1;
     $this->Mensaje='Error en el proceso consulte con el administrador.';
     $this->MensajeError=$e->getMessage();
    }
  }
  public function insrt_Domicilio($PerTIde,$PerIdeNro,$PerPais,$PerDept,$PerProv,$PerDist,$PerDirecc)
  {
    try{
     
      $param=array($PerTIde,$PerIdeNro,$PerPais,$PerDept,$PerProv,$PerDist,$PerDirecc);
     
        while(true){
          $sql='Call sp_insrt_Domicilio(?,?,?,?,?,?,?)';
          $data=$this->db->query($sql,$param);
          return $data;

        }

    }catch(Exception $e){
      $this->Estado=-1;
      $this->Mensaje='Error en el proceso consulte con el administrador.';
      $this->MensajeError=$e->getMessage();
    }
  }

  public function updt_Hijos($PerApePat,$PerApeMat,$PerNom,$PerNomCo,$PerFchNac,$PerCliente,$PerTide,$PerIdeNro){
    try{
      $sql="Call sp_updt_Hijos(?,?,?,?,?,?,?,?)";
      $param=array($PerApePat,$PerApeMat,$PerNom,$PerNomCo,$PerFchNac,$PerCliente,$PerTide,$PerIdeNro);
      $data=$this->db->query($sql,$param);
      return $data;
    }catch(Exception $e){
      $this->Estado=-1;
      $this->Mensaje='Error en el proceso consulte con el administrador.';
      $this->MensajeError=$e->getMessage();
    }

  }

  
  public function updt_ClienteRepresentante($PerTIde,$PerIdeNro,$PerApePat,$PerApeMat,$PerNom,$PerNomCo,$PerNacion,$PerEmail,$PerTlfNro,$PerObser,$PerDirDes){
    try{
      $sql="Call sp_updt_ClienteRepresentante(?,?,?,?,?,?,?,?,?,?,?)";
      $param=array($PerTIde,$PerIdeNro,$PerApePat,$PerApeMat,$PerNom,$PerNomCo,$PerNacion,$PerEmail,$PerTlfNro,$PerObser,$PerDirDes);
      $data=$this->db->query($sql,$param);
      return $data;
    }catch(Exception $e){
      $this->Estado=-1;
      $this->Mensaje='Error en el proceso consulte con el administrador.';
      $this->MensajeError=$e->getMessage();
    }

  }

  public function updt_Domicilio($PerPais,$PerDept,$PerProv,$PerDist,$PerDirecc,$PerTIde,$PerIdeNro,$PerDirCod)
  {
    try{
     
      $param=array($PerPais,$PerDept,$PerProv,$PerDist,$PerDirecc,$PerTIde,$PerIdeNro,$PerDirCod);
     
        while(true){
          $sql='Call sp_updt_Domicilio(?,?,?,?,?,?,?,?)';
          $data=$this->db->query($sql,$param);
          return $data;

        }

    }catch(Exception $e){
      $this->Estado=-1;
      $this->Mensaje='Error en el proceso consulte con el administrador.';
      $this->MensajeError=$e->getMessage();
    }
  }
  public function dlt_Domicilio($PerTIde,$PerIdeNro,$PerDirCod)
  {
    try{
     
      $param=array($PerTIde,$PerIdeNro,$PerDirCod);
     
        while(true){
          $sql='Call sp_dlt_Domicilio(?,?,?)';
          $data=$this->db->query($sql,$param);
          return $data;

        }

    }catch(Exception $e){
      $this->Estado=-1;
      $this->Mensaje='Error en el proceso consulte con el administrador.';
      $this->MensajeError=$e->getMessage();
    }
  }
  public function dlt_Hijos($PerTIde,$PerIdeNro)
  {
    try{
     
      $param=array($PerTIde,$PerIdeNro);
     
        while(true){
          $sql='Call sp_dlt_Hijos(?,?)';
          $data=$this->db->query($sql,$param);
          return $data;

        }

    }catch(Exception $e){
      $this->Estado=-1;
      $this->Mensaje='Error en el proceso consulte con el administrador.';
      $this->MensajeError=$e->getMessage();
    }
  }

}