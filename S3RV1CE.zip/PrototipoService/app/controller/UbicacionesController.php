<?php
require_once dirname(__FILE__, 3) . "./app/libs/functions.php";
require_once dirname(__FILE__, 3) . "./app/model/UbicacionesModel.php";
header('Access-Control-Allow-Origin: *');
session_start();
$_POST['op'] = isset($_POST['op']) ? $_POST['op'] : die();


switch ($_POST['op']) {
    case 'ListarUbicacionALL';
        $cm=new UbicacionesModel;
        $dataDB=$cm->ListarUbicacionALL();
        echo json_encode($dataDB);
    break;
    case 'ListarDistritoALL';
        $cm=new UbicacionesModel;
        $dataDB=$cm->ListarDistritoALL();
        echo json_encode($dataDB);
    break;
    case 'ListarCategoriasALL';
        $cm=new UbicacionesModel;
        $dataDB=$cm->ListarCategoriasALL();
        echo json_encode($dataDB);
    break;
    case 'SP_ListarFiltro';
        $cm=new UbicacionesModel;
        $dataDB=$cm->SP_ListarFiltro($_POST['idCategorias'],$_POST['idDistrito']);
        echo json_encode($dataDB);
    break;
    default:
    break;
}