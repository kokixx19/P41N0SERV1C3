<?php

require_once dirname(__FILE__, 3) . "./app/db/DB.php";
require_once dirname(__FILE__, 3) . "./app/services/GeneralServices.php";

class UbicacionesModel
{
    public function __construct()
    {
        $this->db = new Conexion;
    }

    public function ListarUbicacionALL()
    {
        try {
            $sql = 'Call sp_ListarUbicacionALL()';
            $param = array();
            $data = $this->db->query($sql);

            return  $data;
        } catch (Exception $e) {
            $this->Estado = -1;
            $this->Mensaje = 'Error en el proceso, consulte con el administrador.';
            $this->MensajeError = $e->getMessage();
        }
    }
    public function ListarCategoriasALL()
    {
        try {
            $sql = 'Call 	SP_ListarCategorias()';
            $param = array();
            $data = $this->db->query($sql);

            return  $data;
        } catch (Exception $e) {
            $this->Estado = -1;
            $this->Mensaje = 'Error en el proceso, consulte con el administrador.';
            $this->MensajeError = $e->getMessage();
        }
    }
    public function ListarDistritoALL()
    {
        try {
            $sql = 'Call SP_ListarDistrito()';
            $param = array();
            $data = $this->db->query($sql);

            return  $data;
        } catch (Exception $e) {
            $this->Estado = -1;
            $this->Mensaje = 'Error en el proceso, consulte con el administrador.';
            $this->MensajeError = $e->getMessage();
        }
    }
    public function SP_ListarFiltro($idCategorias,$idDistrito)
    {
        try {
            $sql = 'Call SP_ListarFiltro(?,?)';
            $param = array($idCategorias,$idDistrito);
            $data = $this->db->query($sql,$param);

            return  $data;
        } catch (Exception $e) {
            $this->Estado = -1;
            $this->Mensaje = 'Error en el proceso, consulte con el administrador.';
            $this->MensajeError = $e->getMessage();
        }
    }
}