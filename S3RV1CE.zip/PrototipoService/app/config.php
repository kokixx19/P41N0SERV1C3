<?php

DEFINE("DB_HOST", "localhost");
DEFINE("DB_NAME", "bd_prototipo");
DEFINE("DB_USER", "root");
DEFINE("DB_PASS", "");

date_default_timezone_set('America/Lima');
